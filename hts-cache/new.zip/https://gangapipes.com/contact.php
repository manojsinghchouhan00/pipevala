<!DOCTYPE html>
<html lang="en">
<head>
<title>Ganga Pipes :: INDIA’S MOST TRUSTED BRAND For Pipes & Fittings</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!-- Fav Icon -->
<link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Arimo:400,400i,700,700i&display=swap" rel="stylesheet">
<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css?var=29" rel="stylesheet">
<link href="assets/css/flaticon.css?var=29" rel="stylesheet">
<link href="assets/css/owl.css?var=29" rel="stylesheet">
<link href="assets/css/bootstrap.css?var=29" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css?var=29" rel="stylesheet">
<link href="assets/css/animate.css?var=29" rel="stylesheet">
<link href="assets/css/color.css?var=29" rel="stylesheet">
<link href="assets/css/rtl.css?var=29" rel="stylesheet">
<link href="assets/css/style.css?var=29" rel="stylesheet">
<link href="assets/css/responsive.css?var=29" rel="stylesheet">
</head>
<!-- page wrapper -->
<body class="boxed_wrapper ltr">
    <!-- Preloader -->
    <div class="loader-wrap">
        <div class="preloader"><div class="preloader-close">Preloader Close</div></div>
        <div class="layer layer-one"><span class="overlay"></span></div>
        <div class="layer layer-two"><span class="overlay"></span></div>        
        <div class="layer layer-three"><span class="overlay"></span></div>        
    </div>
	    <!-- main header -->
    <header class="main-header style-one style-six">
        <div class="header-top">
            <div class="auto-container">
                <div class="top-inner clearfix">
                    <ul class="info top-left pull-left">
                        <li><i class="fas fa-map-marker-alt"></i>Veraval-Shapar, Rajkot (Gujarat) INDIA</li>
                    </ul>
                    <ul class="info top-left pull-left">
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<svg style="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="16" height="16" viewBox="0 0 256 256" xml:space="preserve">
<g transform="translate(128 128) scale(0.72 0.72)" style="">
	<g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(-175.05 -175.05000000000004) scale(3.89 3.89)" >
	<path d="M 38.789 51.211 l 10.876 10.876 c 0.974 0.974 2.471 1.194 3.684 0.543 l 13.034 -6.997 c 0.964 -0.518 2.129 -0.493 3.07 0.066 l 19.017 11.285 c 1.357 0.805 1.903 2.489 1.268 3.933 c -1.625 3.698 -4.583 10.476 -5.758 13.473 c -0.247 0.631 -0.615 1.209 -1.127 1.652 c -12.674 10.986 -37.89 -2.4 -57.191 -21.701 C 6.358 45.039 -7.028 19.823 3.958 7.149 c 0.444 -0.512 1.022 -0.88 1.652 -1.127 c 2.996 -1.175 9.775 -4.133 13.473 -5.758 c 1.444 -0.635 3.128 -0.089 3.933 1.268 l 11.285 19.017 c 0.558 0.941 0.583 2.106 0.066 3.07 L 27.37 36.651 c -0.651 1.213 -0.431 2.71 0.543 3.684 C 27.913 40.335 38.789 51.211 38.789 51.211 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(237,50,55); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
	<path d="M 90 49.5 h -9 C 81 27.168 62.832 9 40.5 9 V 0 C 67.794 0 90 22.206 90 49.5 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(237,50,55); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
	<path d="M 72.5 49.5 h -9 c 0 -12.682 -10.317 -23 -23 -23 v -9 C 58.145 17.5 72.5 31.855 72.5 49.5 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(237,50,55); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
</g>
</g>
</svg>&nbsp;&nbsp;
Inquiry / Complaint: <a href="tel:18003130822">1800 313 0822</a></li>
                    </ul>
                    <div class="top-right pull-right">
                        <ul class="social-links clearfix">
															<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
																						<li><a href="https://in.linkedin.com/company/gangapipesindia" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
																						<li><a href="https://www.instagram.com/gangapipes/" target="_blank"><i class="fab fa-instagram"></i></a></li>
																						<li><a href="https://www.youtube.com/channel/UCRlxf7kGZzCaQeEGFwRvwQw/featured" target="_blank"><i class="fab fa-youtube"></i></a></li>
																						<li><a href="https://wa.me/919725534743?text=I'm%20interested%20in%20your%20Products" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
							                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-lower">
            <div class="auto-container">
                <div class="outer-box clearfix">
                    <div class="logo-box pull-left">
                        <figure class="logo"><a href="#"><img src="assets/images/footer-logo.png" alt=""></a></figure>
                    </div>
                    <div class="menu-area pull-right">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                        </div>
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li class=""><a href="http://gangapipes.com/">Home</a>
                                    </li> 
                                    <li class=""><a href="company-profile.php">Company Profile</a>
									<!--
                                        <ul>
																								
													<li><a href="pages.php?pid=4">Who We Are</a></li>
																									
													<li><a href="pages.php?pid=5">Quality</a></li>
																									
													<li><a href="pages.php?pid=6">Why Us</a></li>
												                                        </ul>
										-->
                                    </li>
                                    <li class="dropdown "><a href="javascript:void(0)">Products</a>
                                        <ul>
																									<li><a href="category.php?cid=1">CPVC Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=2">UPVC Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=3">UPVC SWR Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=4">Agri Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=5">PPR Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=6">HDPE Pipes</a></li>
																											<li><a href="category.php?cid=7">Drip Irrigation System</a></li>
																											<li><a href="category.php?cid=8">Sprinkler Irrigation System</a></li>
																											<li><a href="category.php?cid=9">Casing Pipes</a></li>
																											<li><a href="category.php?cid=10">PE-X Pipes</a></li>
													                                        </ul>
                                    </li>
                                    <li class=""><a href="Ganga-Pipes-Catalogue.pdf" target="_blank">Catalogue</a>
                                    </li>
                                    <li class="current"><a href="contact.php">Contact</a></li>
                                </ul>
                            </div>
                        </nav>
                        <div class="menu-right-content clearfix">
                            <div class="btn-box">
                                <a href="inquiry.php" class="theme-btn style-one">Inquiry</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--sticky Header-->
        <div class="sticky-header">
            <div class="auto-container">
                <div class="outer-box clearfix">
                    <div class="logo-box pull-left">
                        <figure class="logo"><a href="#"><img src="assets/images/small-logo.png" alt=""></a></figure>
                    </div>
                    <div class="menu-area pull-right">
                        <nav class="main-menu clearfix">
                            <!--Keep This Empty / Menu will come through Javascript-->
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- main-header end -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><i class="fas fa-times"></i></div>
        
        <nav class="menu-box">
            <div class="nav-logo"><a href="#"><img src="assets/images/logo.png" alt="" title=""></a></div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            <div class="contact-info">
                <h4>Contact Info</h4>
                <ul>
                    <li>Veraval-Shapar, Rajkot (Gujarat) INDIA</li>
                    <li><a href="18003130822">1800 313 0822</a></li>
                    <li><a href="mailto:info@gangapipes.com">info@gangapipes.com</a></li>
                </ul>
            </div>
            <div class="social-links">
                <ul class="clearfix">
															<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
																						<li><a href="https://in.linkedin.com/company/gangapipesindia" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
																						<li><a href="https://www.instagram.com/gangapipes/" target="_blank"><i class="fab fa-instagram"></i></a></li>
																						<li><a href="https://www.youtube.com/channel/UCRlxf7kGZzCaQeEGFwRvwQw/featured" target="_blank"><i class="fab fa-youtube"></i></a></li>
																						<li><a href="https://wa.me/919725534743?text=I'm%20interested%20in%20your%20Products" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
							                </ul>
            </div>
        </nav>
    </div><!-- End Mobile Menu -->    <!-- banner-section -->
    <!--Page Title-->
    <section class="page-title centred" style="background-image: url(assets/images/background/page-title-51.jpg);">
        <div class="auto-container">
            <div class="content-box clearfix">
                <h1>Contact Us</h1>
                <ul class="bread-crumb clearfix">
                    <li><a href="/">Home</a></li>
                    <li>Get In Touch</li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Page Title-->
    <!-- contact-information -->
    <section class="contact-information centred">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                    <div class="single-item wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-box"><i class="far fa-map"></i></div>
                            <h3>Office Location</h3>
                            <p>Survey No. 211, Plot No. 9 & 11, Narmada Pipes Gate, National Highway - 27, Veraval (Shapar)-360024, Tal: Kotda Sangani, Dist: Rajkot, Gujarat, INDIA</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                    <div class="single-item wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-box"><i class="fas fa-phone"></i></div>
                            <h3>Calling Support</h3>
                            <p><a href="tel:18003130822">1800 313 0822</a></p>
							<p>&nbsp;</p>
							<p>&nbsp;</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                    <div class="single-item wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="icon-box"><i class="far fa-envelope-open"></i></div>
                            <h3>Email Information</h3>
                            <p><a href="mailto:1800 313 0822">info@gangapipes.com</a></p>
							<div class="contactsocial">
							<ul class="social-links clearfix">
																	<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
																									<li><a href="https://in.linkedin.com/company/gangapipesindia" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
																									<li><a href="https://www.instagram.com/gangapipes/" target="_blank"><i class="fab fa-instagram"></i></a></li>
																									<li><a href="https://www.youtube.com/channel/UCRlxf7kGZzCaQeEGFwRvwQw/featured" target="_blank"><i class="fab fa-youtube"></i></a></li>
																									<li><a href="https://wa.me/919725534743?text=I'm%20interested%20in%20your%20Products" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
															</ul>
							</div>
                        </div>
                    </div>
                </div>
            </div>
			<div style="clear:both;height:100px;"></div>
        </div>
    </section>
    <!-- contact-information end -->
    <!-- contact-style-two -->
    <section class="contact-style-two" style="background-image: url(assets/images/background/contact-3.jpg);">
        <div class="auto-container row">
            <div class="col-xl-6 col-lg-12 col-md-12">
                <div class="sec-title left light">
                    <h5>try our service</h5>
                    <h2>Drop Us a Line</h2>
                </div>
                <form method="post" action="contactform.php" name="f1" id="contact-form" class="default-form">
                    <div class="row clearfix">
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input type="text" name="username" placeholder="Your Name" required="">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input type="email" name="email" placeholder="Email address" required="">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input type="text" name="phone" placeholder="Phone" required="">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                            <input type="text" name="subject" placeholder="Subject" required="">
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                            <textarea name="message" placeholder="Message"></textarea>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn">
                            <button class="theme-btn style-one" type="submit" name="submit-form">Send Request</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-xl-6 col-lg-12 col-md-12" style="padding-top:121px;">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3695.299583047037!2d70.79122171442657!3d22.152665553836997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3958359e85ea6599%3A0x5a5e2753b9bb73d5!2sGanga%20Piping%20Solutions%20Pvt%20Ltd!5e0!3m2!1sen!2sin!4v1656583604621!5m2!1sen!2sin" width="100%" height="394" style="border:0;border-radius:10px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </section>
    <!-- contact-style-two end -->
	


    <!-- cta-section -->
    <section class="cta-section">
        <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-3.png);"></div>
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title pull-left">
                    <h2>Request A Quote</h2>
                </div>
                <div class="btn-box pull-right">
                    <a href="inquiry.php">get in touch</a>
                </div>
            </div>
        </div>
    </section>
    <!-- cta-section end -->


    <!-- fun-fact -->
    <section class="fun-fact centred">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="2500">0</span>+
                        </div>
                        <p>Dealer Network</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="150">0</span>+
                        </div>
                        <p>Distributor Network</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="2">0</span>M+
                        </div>
                        <p>Satisfied Customers</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="1000">0</span>+
                        </div>
                        <p>Projects Delivered</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- fun-fact end -->


    <!-- main-footer -->
    <footer class="main-footer">
        <div class="footer-top">
            <div class="auto-container">
                <div class="widget-section">
                    <div class="row clearfix">
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="#"><img src="assets/images/footer-logo.png" alt=""></a></figure>
								<p style="width:90%">Serving The World Since More Than 30 Years and Having Expertise in Manufacturing of CPVC, UPVC, & SWR Pipes & Fittings.<br /><br /></p>
                                <ul class="social-links clearfix">
															<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
																						<li><a href="https://in.linkedin.com/company/gangapipesindia" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
																						<li><a href="https://www.instagram.com/gangapipes/" target="_blank"><i class="fab fa-instagram"></i></a></li>
																						<li><a href="https://www.youtube.com/channel/UCRlxf7kGZzCaQeEGFwRvwQw/featured" target="_blank"><i class="fab fa-youtube"></i></a></li>
																						<li><a href="https://wa.me/919725534743?text=I'm%20interested%20in%20your%20Products" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
							                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
								<div class="widget-title">
                                    &nbsp;
                                </div>
                                <ul class="info-list clearfix" style="padding-top:20px;">
                                    <li><i class="fas fa-map-marker-alt"></i>Survey No. 211, Plot No. 9 & 11, Narmada Pipes Gate, National Highway - 27, Veraval (Shapar)-360024, Tal: Kotda Sangani, Dist: Rajkot, Gujarat, INDIA</li>
                                    <li><i class="fas fa-envelope"></i>Email: <a href="mailto:info@gangapipes.com">info@gangapipes.com</a></li>
                                    <li><i class="fas fa-headphones"></i>Call: <a href="tel:18003130822">1800 313 0822</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml-70">
                                <div class="widget-title">
                                    <h4>Useful Links</h4>
                                </div>
                                <div class="widget-content">
                                    <ul class="list clearfix row">
																									<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=1">CPVC Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=2">UPVC Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=3">UPVC SWR Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=4">Agri Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=5">PPR Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=6">HDPE Pipes</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=7">Drip Irrigation System</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=8">Sprinkler Irrigation System</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=9">Casing Pipes</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=10">PE-X Pipes</a></li>
													                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="copyright"><p>&copy; 2022 <a href="#">Ganga Pipes</a>. All rights reserved.</p></div>
            </div>
        </div>
    </footer>
    <!-- main-footer end -->

    <!--Scroll to top-->
    <button class="scroll-top scroll-to-target" data-target="html">
        <span class="fa fa-arrow-up"></span>
    </button><!-- jequery plugins -->
<div style="position:fixed;z-index:4444;background: rgba(0,0,0,0.4);width: 200px;bottom:12px;right:15px;padding: 0px 10px;border-radius: 5px;color: #fff;font-size: 13px;display:none;" id="rightclick">
	Right Click Disabled.
</div>
<script src="assets/js/jquery.js?var=29"></script>
<script src="assets/js/popper.min.js?var=29"></script>
<script src="assets/js/bootstrap.min.js?var=29"></script>
<script src="assets/js/owl.js?var=29"></script>
<script src="assets/js/wow.js?var=29"></script>
<script src="assets/js/validation.js?var=29"></script>
<script src="assets/js/jquery.fancybox.js?var=29"></script>
<script src="assets/js/appear.js?var=29"></script>
<script src="assets/js/jquery.countTo.js?var=29"></script>
<script src="assets/js/scrollbar.js?var=29"></script>
<script src="assets/js/nav-tool.js?var=29"></script>
<script src="assets/js/TweenMax.min.js?var=29"></script>
<script src="assets/js/circle-progress.js?var=29"></script>
<script src="assets/js/jquery.nice-select.min.js?var=29"></script>
<!-- main-js -->
<script src="assets/js/script.js?var=29"></script>
<script type="text/javascript">
var rclickblock = $("#rightclick");
$(document).bind("contextmenu",function(e){
		rclickblock.show();
		setInterval(function() {
			rclickblock.hide();
		}, 2000);
		return false;
    });
</script><script type="text/javascript">
	function submitContact(e){
		var username = document.f1.username;
		var email = document.f1.email;
		var phone = document.f1.phone;
		var subject = document.f1.subject;
		var message = document.f1.message;
		
		if(username.value != ""){
			alert("Please Enter Your Name!!");
			username.focus();
			return false;
		}
		
		if(email.value != ""){
			alert("Please Enter Your Email!!");
			email.focus();
			return false;
		}

		if(phone.value != ""){
			alert("Please Enter Your Contact Number!!");
			phone.focus();
			return false;
		}

		if(subject.value != ""){
			alert("Please Enter Subject!!");
			subject.focus();
			return false;
		}

		if(message.value != ""){
			alert("Please Enter Message!!");
			message.focus();
			return false;
		}
	}
		</script>
</body><!-- End of .page_wrapper -->
</html>