<!DOCTYPE html>
<html lang="en">
<head>
<title>Ganga Pipes :: INDIA’S MOST TRUSTED BRAND For Pipes & Fittings</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!-- Fav Icon -->
<link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Arimo:400,400i,700,700i&display=swap" rel="stylesheet">
<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css?var=29" rel="stylesheet">
<link href="assets/css/flaticon.css?var=29" rel="stylesheet">
<link href="assets/css/owl.css?var=29" rel="stylesheet">
<link href="assets/css/bootstrap.css?var=29" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css?var=29" rel="stylesheet">
<link href="assets/css/animate.css?var=29" rel="stylesheet">
<link href="assets/css/color.css?var=29" rel="stylesheet">
<link href="assets/css/rtl.css?var=29" rel="stylesheet">
<link href="assets/css/style.css?var=29" rel="stylesheet">
<link href="assets/css/responsive.css?var=29" rel="stylesheet">
</head>
<!-- page wrapper -->
<body class="boxed_wrapper ltr">
    <!-- Preloader -->
    <div class="loader-wrap">
        <div class="preloader"><div class="preloader-close">Preloader Close</div></div>
        <div class="layer layer-one"><span class="overlay"></span></div>
        <div class="layer layer-two"><span class="overlay"></span></div>        
        <div class="layer layer-three"><span class="overlay"></span></div>        
    </div>
	    <!-- main header -->
    <header class="main-header style-one ">
        <div class="header-top">
            <div class="auto-container">
                <div class="top-inner clearfix">
                    <ul class="info top-left pull-left">
                        <li><i class="fas fa-map-marker-alt"></i>Veraval-Shapar, Rajkot (Gujarat) INDIA</li>
                    </ul>
                    <ul class="info top-left pull-left">
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<svg style="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="16" height="16" viewBox="0 0 256 256" xml:space="preserve">
<g transform="translate(128 128) scale(0.72 0.72)" style="">
	<g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(-175.05 -175.05000000000004) scale(3.89 3.89)" >
	<path d="M 38.789 51.211 l 10.876 10.876 c 0.974 0.974 2.471 1.194 3.684 0.543 l 13.034 -6.997 c 0.964 -0.518 2.129 -0.493 3.07 0.066 l 19.017 11.285 c 1.357 0.805 1.903 2.489 1.268 3.933 c -1.625 3.698 -4.583 10.476 -5.758 13.473 c -0.247 0.631 -0.615 1.209 -1.127 1.652 c -12.674 10.986 -37.89 -2.4 -57.191 -21.701 C 6.358 45.039 -7.028 19.823 3.958 7.149 c 0.444 -0.512 1.022 -0.88 1.652 -1.127 c 2.996 -1.175 9.775 -4.133 13.473 -5.758 c 1.444 -0.635 3.128 -0.089 3.933 1.268 l 11.285 19.017 c 0.558 0.941 0.583 2.106 0.066 3.07 L 27.37 36.651 c -0.651 1.213 -0.431 2.71 0.543 3.684 C 27.913 40.335 38.789 51.211 38.789 51.211 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(237,50,55); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
	<path d="M 90 49.5 h -9 C 81 27.168 62.832 9 40.5 9 V 0 C 67.794 0 90 22.206 90 49.5 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(237,50,55); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
	<path d="M 72.5 49.5 h -9 c 0 -12.682 -10.317 -23 -23 -23 v -9 C 58.145 17.5 72.5 31.855 72.5 49.5 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(237,50,55); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" />
</g>
</g>
</svg>&nbsp;&nbsp;
Inquiry / Complaint: <a href="tel:18003130822">1800 313 0822</a></li>
                    </ul>
                    <div class="top-right pull-right">
                        <ul class="social-links clearfix">
															<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
																						<li><a href="https://in.linkedin.com/company/gangapipesindia" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
																						<li><a href="https://www.instagram.com/gangapipes/" target="_blank"><i class="fab fa-instagram"></i></a></li>
																						<li><a href="https://www.youtube.com/channel/UCRlxf7kGZzCaQeEGFwRvwQw/featured" target="_blank"><i class="fab fa-youtube"></i></a></li>
																						<li><a href="https://wa.me/919725534743?text=I'm%20interested%20in%20your%20Products" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
							                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-lower">
            <div class="auto-container">
                <div class="outer-box clearfix">
                    <div class="logo-box pull-left">
                        <figure class="logo"><a href="#"><img src="assets/images/logo.png" alt=""></a></figure>
                    </div>
                    <div class="menu-area pull-right">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                        </div>
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li class="current"><a href="http://gangapipes.com/">Home</a>
                                    </li> 
                                    <li class=""><a href="company-profile.php">Company Profile</a>
									<!--
                                        <ul>
																								
													<li><a href="pages.php?pid=4">Who We Are</a></li>
																									
													<li><a href="pages.php?pid=5">Quality</a></li>
																									
													<li><a href="pages.php?pid=6">Why Us</a></li>
												                                        </ul>
										-->
                                    </li>
                                    <li class="dropdown "><a href="javascript:void(0)">Products</a>
                                        <ul>
																									<li><a href="category.php?cid=1">CPVC Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=2">UPVC Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=3">UPVC SWR Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=4">Agri Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=5">PPR Pipes & Fittings</a></li>
																											<li><a href="category.php?cid=6">HDPE Pipes</a></li>
																											<li><a href="category.php?cid=7">Drip Irrigation System</a></li>
																											<li><a href="category.php?cid=8">Sprinkler Irrigation System</a></li>
																											<li><a href="category.php?cid=9">Casing Pipes</a></li>
																											<li><a href="category.php?cid=10">PE-X Pipes</a></li>
													                                        </ul>
                                    </li>
                                    <li class=""><a href="Ganga-Pipes-Catalogue.pdf" target="_blank">Catalogue</a>
                                    </li>
                                    <li class=""><a href="contact.php">Contact</a></li>
                                </ul>
                            </div>
                        </nav>
                        <div class="menu-right-content clearfix">
                            <div class="btn-box">
                                <a href="inquiry.php" class="theme-btn style-one">Inquiry</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--sticky Header-->
        <div class="sticky-header">
            <div class="auto-container">
                <div class="outer-box clearfix">
                    <div class="logo-box pull-left">
                        <figure class="logo"><a href="#"><img src="assets/images/small-logo.png" alt=""></a></figure>
                    </div>
                    <div class="menu-area pull-right">
                        <nav class="main-menu clearfix">
                            <!--Keep This Empty / Menu will come through Javascript-->
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- main-header end -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><i class="fas fa-times"></i></div>
        
        <nav class="menu-box">
            <div class="nav-logo"><a href="#"><img src="assets/images/logo.png" alt="" title=""></a></div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            <div class="contact-info">
                <h4>Contact Info</h4>
                <ul>
                    <li>Veraval-Shapar, Rajkot (Gujarat) INDIA</li>
                    <li><a href="18003130822">1800 313 0822</a></li>
                    <li><a href="mailto:info@gangapipes.com">info@gangapipes.com</a></li>
                </ul>
            </div>
            <div class="social-links">
                <ul class="clearfix">
															<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
																						<li><a href="https://in.linkedin.com/company/gangapipesindia" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
																						<li><a href="https://www.instagram.com/gangapipes/" target="_blank"><i class="fab fa-instagram"></i></a></li>
																						<li><a href="https://www.youtube.com/channel/UCRlxf7kGZzCaQeEGFwRvwQw/featured" target="_blank"><i class="fab fa-youtube"></i></a></li>
																						<li><a href="https://wa.me/919725534743?text=I'm%20interested%20in%20your%20Products" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
							                </ul>
            </div>
        </nav>
    </div><!-- End Mobile Menu -->    <!-- banner-section -->
    <section class="banner-section">
        <div class="banner-carousel owl-theme owl-carousel owl-loaded owl-drag">
			            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1658580017banner11.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>CPVC Piping Solutions </h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">For <span style="color:#F8ACAE">Hot</span> and <span style="color:#A7DEFB">Cold</span> Water</h3>
                        <p style="color:#fff;">which provides Long-Lasting Results And High-End Functionality</p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=1" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1658579754banner21.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>UPVC Pipes & Fittings</h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">Excellent For <span style="color:#A7DEFB">Cold</span> Water Application </h3>
                        <p style="color:#fff;"></p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=2" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1658579788banner31.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>uPVC SWR Pipes & Fittings</h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">Used For <span style="color:#F8ACAE">Sewage, Waste,</span> & <span style="color:#F8ACAE">Rain</span> Drainage Water System</h3>
                        <p style="color:#fff;"></p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=3" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1659185942banner9.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>Agriculture PVC Pressure Pipes & Fittings</h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">It's <span style="color:#F8ACAE">Economical, Long-lasting</span> & <span style="color:#F8ACAE">Easy Installation</span></h3>
                        <p style="color:#fff;">Can Be Used For Water Supply In The Farms & Different Distribution System</p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=4" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1658580555banner5.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>PPR Pipes & Fittings</h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">Are <span style="color:#F8ACAE">Anti-Bacterial, Hygienic</span> & <span style="color:#F8ACAE">Blockage Free</span></h3>
                        <p style="color:#fff;">Appreciated For Their Energy Conversation & Heat Preservation Characteristic</p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=5" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1658580833banner4.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>Casing Pipes</h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">Provide <span style="color:#F8ACAE">Low Friction</span> & <span style="color:#F8ACAE">High Flow</span></h3>
                        <p style="color:#fff;">Are Used for Various Underground Applications</p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=9" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1658580966banner6.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>HDPE Pipes</h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">Acknowledged for their <span style="color:#F8ACAE">Efficiency</span> & <span style="color:#F8ACAE">Durability</span></h3>
                        <p style="color:#fff;">Support Many Industrial Usages Like Construction, Agriculture etc.</p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=6" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				            <div class="slide-item">
                <div class="image-layer" style="background-image:url(http://gangapipes.com//upload/banner/1659185032banner71.jpg)"></div>
                <div class="auto-container">
                    <div class="content-box">
                        <h5>Ganga provides advanced</h5>
                        <h1>Drip & Sprinkler Irrigation System</h1>
                        <h3 style="color:#fff;font-size:28px;line-height:35px;">Provide <span style="color:#F8ACAE">Superior Quality</span> & <span style="color:#F8ACAE">Controlled</span> Irrigation Systems</h3>
                        <p style="color:#fff;">Used on Almost all the Crops Grown in Country Like Wheat, Gram, Soyabean, Vegetables, Cotton etc.</p>
						<p>&nbsp;</p>
                        <div class="btn-box">
                            <a href="http://gangapipes.com/newweb/category.php?cid=8" class="theme-btn style-one">View Details</a>
                        </div>
                    </div>  
                </div>
            </div>
				        </div>
    </section>
    <!-- banner-section end -->
    <!-- info-section -->
    <section class="info-section">
        <div class="auto-container">
            <div class="row clearfix">
								                <div class="col-lg-7 col-md-12 col-sm-12 title-column">
                    <div class="title-inner">
                        <div class="year-box">
							<div style="width:150px;height:150px;background:url('assets/images/since.png') no-repeat top center;background-size:cover;font-size: 42px;line-height:14px;padding-top: 75px;font-weight: bolder !important;color: #622500;text-align: center;">
								33<br />
								<span style="font-size:11px;line-height:13px;">Years</span>
							</div>
							<!--
                            <figure class="image-box"><img src="assets/images/icons/year-icon.png" alt=""></figure>
                            <h2>32</h2>
                            <h3 style="font-size:18px;font-weight:bold;">Since 1992</h3>
							-->
                        </div>
                        <div class="title">
							<h2>India&rsquo;s<br />Most Trusted Brand <br /><span>&mdash;</span> <span style="font-size: 28px;">For Pipes &amp; Fittings</span></h2>                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 col-sm-12 text-column">
                    <div class="text">
						<p><strong>Ganga</strong> is well known and most trusted brand in India and abroad market. Top management having experience of manufacturing plastic pipes and fittings about more than 3 decades. Organisation having large product portfolio like <strong>CPVC, UPVC, SWR, AGRI, Irrigation, HDPE, Sprinkler</strong> etc.</p>                        <a href="http://gangapipes.com/newweb/pages.php?pid=4"><i class="fas fa-arrow-right"></i><span>Who We Are </span></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://gangapipes.com/newweb/pages.php?pid=6"><i class="fas fa-arrow-right"></i><span>Why Use </span></a>
                    </div>
                </div>
				            </div>
        </div>
    </section>
    <!-- info-section end -->


    <!-- feature-section -->
    <section class="feature-section">
        <div class="auto-container">
            <div class="row clearfix">
											<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496134feature-1.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>CPVC Pipes & Fittings</h3>
												<a href="category.php?cid=1"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496161feature-2.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>UPVC Pipes & Fittings</h3>
												<a href="category.php?cid=2"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496179feature-3.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>UPVC SWR Pipes & Fittings</h3>
												<a href="category.php?cid=3"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496213feature-11.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>Agri Pipes & Fittings</h3>
												<a href="category.php?cid=4"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496238feature-21.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>PPR Pipes & Fittings</h3>
												<a href="category.php?cid=5"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496269feature-31.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>HDPE Pipes</h3>
												<a href="category.php?cid=6"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496292feature-113.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>Drip Irrigation System</h3>
												<a href="category.php?cid=7"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496314feature-212.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>Sprinkler Irrigation System</h3>
												<a href="category.php?cid=8"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/1656496340feature-312.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>Casing Pipes</h3>
												<a href="category.php?cid=9"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
													<div class="col-lg-4 col-md-6 col-sm-12 feature-block" style="margin-bottom:40px;">
								<div class="feature-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
									<div class="inner-box">
										<figure class="image-box"><img src="http://gangapipes.com//upload/category/16595094630PEX-Pipes-copy1.jpg" alt=""></figure>
										<div class="lower-content">
											<div class="inner">
												<h3>PE-X Pipes</h3>
												<a href="category.php?cid=10"><span>Read more</span><i class="fas fa-arrow-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
						            </div>
        </div>
    </section>
    <!-- feature-section end -->


    <!-- about-section -->
    <section class="about-section bg-color-1"> 
        <div class="auto-container">
            <div class="row clearfix">
			<!-- video-column -->
				                <div class="col-lg-6 col-md-12 col-sm-12 ">
                    <div class="video-inner">
                        <figure class="image-box"><img src="http://gangapipes.com//upload/cms/1656511228about-1.png" alt="Quality"></figure>
						<!--
                        <div class="video-btn">
                            <a href="https://www.youtube.com/watch?v=nfP5N9Yc72A&amp;t=28s" class="lightbox-image" data-caption="" style="background-image: url(assets/images/resource/btn-bg.png);"><i class="fas fa-play"></i></a>
                        </div>
						-->
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div id="content_block_one">
                        <div class="content-box">
                            <div class="sec-title left">
                               <h5>Quality</h5>
<h2>Ganga Pipes</h2>
<h3>constantly strives to upgrade processes and materials incorporating international developments in the plumbing industry to benefit the customers.</h3>                            </div>
                            <div class="text">
								<p style="padding-bottom: 10px;">Owing to our highest technical performance, we are engaged in manufacturing, exporting and supplying best quality CPVC, UPVC and SWR Pipes and Fittings.</p>
<p style="padding-bottom: 10px;">Top management having experience of manufacturing pipes and fittings for more than 3 decades.</p>
<p style="padding-bottom: 10px; display: none;">Quality has always been the cornerstone of our company. ASTM and ISI certification is a clear evidence of our quality-oriented approach. Our comprehensive quality program has always been based on the continual improvements in our products, process and system which are designed to meet the specific customers&rsquo; needs and satisfaction. Our dedicated team of quality control executives keeps a strict vigil at each stage of production to ensure the impeccable quality of our Plastic Pipes &amp; Fittings.</p>
<p style="font-weight: bold;">All the products are as per Government Standards or International Standards i.e. ASTM D 2846, ASTM F 439, ASTM D 2467, ASTM D 1785, IS: 15778, etc.</p>
<p style="padding-top: 30px;"><img src="assets/images/qulitylogo/c1.png" alt="" width="50" />&nbsp;<img src="assets/images/qulitylogo/c2.png" alt="" width="50" />&nbsp;<img src="assets/images/qulitylogo/c3.png" alt="" width="50" />&nbsp;<img src="assets/images/qulitylogo/c4.png" alt="" width="50" />&nbsp;<img src="assets/images/qulitylogo/c5.png" alt="" width="50" />&nbsp;<img src="assets/images/qulitylogo/c6.png" alt="" width="50" />&nbsp;<img src="assets/images/qulitylogo/c7.png" alt="" width="50" />&nbsp;<img src="assets/images/qulitylogo/c8.png" alt="" width="50" /></p>                            </div>
                        </div>
                    </div>
                </div>
				            </div>
        </div>
    </section>
    <!-- about-section end -->

    <!-- world-cyber -->
    <section class="world-cyber service-style-three">
		<!-- style="background-image: url(assets/images/shape/shape-2.png);" -->
        <div class="pattern-layer" ></div>
        <div class="auto-container">
            <div class="sec-title centred" style="margin-bottom:100px;">
                <h5>Product Range</h5>
                <h2>Popular Products</h2>
            </div>
            <div class="three-item-carousel owl-carousel owl-theme owl-nav-none">
											<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=1"><img src="http://gangapipes.com//upload/products/16578877871-pipe-3-meter.jpg" alt="Pipe - 3mtr">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=1">Pipe - 3mtr</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=29"><img src="http://gangapipes.com//upload/products/16579680061-pipe-3-mtr.jpg" alt="Pipe 3 Mtr.">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=29">Pipe 3 Mtr.</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=53"><img src="http://gangapipes.com//upload/products/1658153599Ring-Type-Pipe-A.jpg" alt="Pipes Type A (Ring)">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=53">Pipes Type A (Ring)</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=10"><img src="http://gangapipes.com//upload/products/165788860610-fta.jpg" alt="FTA">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=10">FTA</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=38"><img src="http://gangapipes.com//upload/products/1658128059UPVCFTA.jpg" alt="FTA">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=38">FTA</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=62"><img src="http://gangapipes.com//upload/products/1658154852Ring-Type-Double-Y.jpg" alt="Double Y (Ring)">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=62">Double Y (Ring)</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=11"><img src="http://gangapipes.com//upload/products/165788891911-reducer-tee.jpg" alt="Reducer Tee">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=11">Reducer Tee</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=39"><img src="http://gangapipes.com//upload/products/1658128839UPVCReducerTee.jpg" alt="Reducer Tee">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=39">Reducer Tee</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=63"><img src="http://gangapipes.com//upload/products/1658154896Bend-87-with-Door.jpg" alt="Bend 87.5� with Door (Ring)">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=63">Bend 87.5� with Door (Ring)</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=12"><img src="http://gangapipes.com//upload/products/165788911812-reducer-coupler.jpg" alt="Reducer Coupler">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=12">Reducer Coupler</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=40"><img src="http://gangapipes.com//upload/products/1658129029UPVCReducerCoupler.jpg" alt="Reducer Coupler">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=40">Reducer Coupler</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=64"><img src="http://gangapipes.com//upload/products/1658154956Ring-Type-Single-Tee-with-Door.jpg" alt="Single Tee with Door (Ring)">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=64">Single Tee with Door (Ring)</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=13"><img src="http://gangapipes.com//upload/products/165788949613-reducer-elbow.jpg" alt="Reducer Elbow">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=13">Reducer Elbow</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=41"><img src="http://gangapipes.com//upload/products/1658129310UPVCReducerElbow.jpg" alt="Reducer Elbow">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=41">Reducer Elbow</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=65"><img src="http://gangapipes.com//upload/products/1658155050Ring-Type-SingleY-with-Door.jpg" alt="Single Y with Door (Ring)">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=65">Single Y with Door (Ring)</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=14"><img src="http://gangapipes.com//upload/products/165788961715-reducer-mta.jpg" alt="Reducer MTA">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=14">Reducer MTA</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=42"><img src="http://gangapipes.com//upload/products/1658129504UPVCReducerBush.jpg" alt="Reducer Bush">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=42">Reducer Bush</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=66"><img src="http://gangapipes.com//upload/products/1658155103Ring-Type-Reduce-Coupler.jpg" alt="Reduce Coupler (Ring)">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=66">Reduce Coupler (Ring)</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=15"><img src="http://gangapipes.com//upload/products/165788970916-reducer-fta.jpg" alt="Reducer FTA">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=15">Reducer FTA</a></h3>
									</div>
								</div>
							</div>
													<div class="service-block-three">
								<div class="inner-box">
									<figure class="image-box">
										<!--
										<div class="overlay-box-1"></div>
										<div class="overlay-box-2"></div>
										-->
										<a href="product-details.php?prdid=43"><img src="http://gangapipes.com//upload/products/1658131065UPVCBrassElbow.jpg" alt="Brass Elbow(F)">
										<!--<i class="fas fa-link"></i>--></a>
									</figure>
									<div class="lower-content">
										<h3 style="font-size:16px;line-height:18px;"><a href="product-details.php?prdid=43">Brass Elbow(F)</a></h3>
									</div>
								</div>
							</div>
						            </div>			
        </div>
    </section>
    <!-- world-cyber end -->


    <!-- support-section -->
    <section class="support-section">
        <div class="auto-container">
            <div class="inner-container">
                <div class="row clearfix">
                    <div class="col-lg-7 col-md-12 col-sm-12 inner-column">
                        <div class="inner-box" style="padding:50px 50px 20px 50px;">
                            <div class="sec-title light left">
                                <h5>Call Back Request</h5>
                                <h2>Quick Contact</h2>
                            </div>
                            <form method="post" action="contactform.php" name="f1" id="contact-form" class="submit-form">
                                <div class="form-group">
                                    <input type="text" name="username" placeholder="Your Name*" required="">
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Email address*" required="">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="phone" placeholder="Phone*" required="">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="subject" placeholder="Subject*" required="">
                                </div>
                                <div class="form-group">
                                    <textarea name="message" placeholder="Message*"></textarea>
                                </div>
                                <div class="form-group message-btn">
                                    <button type="submit" class="theme-btn style-one">Send Request</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12 col-sm-12 info-column">
                        <div class="info-inner">
                            <figure class="image-box"><img src="assets/images/resource/info-11.jpg" alt=""></figure>
                            <div class="info-box" style="background:rgba(0,0,0,0.5);position:absolute;width:100%;bottom:1px;">
                                <div class="icon-box"><i class="fas fa-phone"></i></div>
								<h2><a href="tel:18003130822">1800 313 0822</a></h2>
                                <div class="email"><a href="mailto:info@gangapipes.com">info@gangapipes.com</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- support-section end -->


    <!-- testimonial-section -->
    <section class="testimonial-section" style="background-image: url(assets/images/background/testimonial-bg.jpg);">
        <div class="auto-container">
										
            <div class="title-box">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 title-column">
                        <div class="sec-title right">
							<h5>For Clients</h5>
							<h2>Satisfaction Is Our Motto</h2>						
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 text-column">
                        <div class="text">
							<p><span>Let&rsquo;s take most of the money we would&rsquo;ve spent on paid advertising and paid marketing and instead of spending it on that invest it in the customer experience / customer service and then let our customers do the marketing for us through word of mouth.</span></p>                        </div>
                    </div>
                </div>
            </div>
				          </div>
	</section>
    <section class="testimonial-section" style="padding-top:120px;background:#B2C8DC;">
        <div class="auto-container">
            <div class="sec-title centred" style="margin-bottom:100px;">
                <h5>Client Says</h5>
                <h2>Testimonials</h2>
            </div>
            <div class="testimonial-inner">
				                <div class="client-testimonial-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
					                    <div class="testimonial-block">
                        <div class="text">
                            <p>Value for money products offering by Ganga Pipes. Specially CPVC, UPVC, and SWR Pipes and fittings quality is tremendous.</p>
                        </div>
                    </div>
					                    <div class="testimonial-block">
                        <div class="text">
                            <p>Wellknown brand since last 30 years and trustworthy people.</p>
                        </div>
                    </div>
					                    <div class="testimonial-block">
                        <div class="text">
                            <p>Superb quality and great support by Ganga team.</p>
                        </div>
                    </div>
					                    <div class="testimonial-block">
                        <div class="text">
                            <p>Such a fantastic brand, plumbers were astonishing after installation.</p>
                        </div>
                    </div>
					                    <div class="testimonial-block">
                        <div class="text">
                            <p>All products are as per standard and without doubt i will use these Ganga brand for cost saving and product durability purpose.</p>
                        </div>
                    </div>
					                </div>
                <div class="client-thumb-outer">
                    <div class="client-thumbs-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
						                        <div class="thumb-item">
                            <figure class="thumb-box"><img src="http://gangapipes.com//upload/testimonials/1656504998testimonial-1.png" alt="K.Balagopal"></figure>
                            <div class="info-box">
                                <h5>K.Balagopal</h5>
                                <span class="designation">Owner</span>
                            </div>
                        </div>
						                        <div class="thumb-item">
                            <figure class="thumb-box"><img src="http://gangapipes.com//upload/testimonials/1656505237testimonial-1.png" alt="Adhikansh Sharma"></figure>
                            <div class="info-box">
                                <h5>Adhikansh Sharma</h5>
                                <span class="designation">Builder</span>
                            </div>
                        </div>
						                        <div class="thumb-item">
                            <figure class="thumb-box"><img src="http://gangapipes.com//upload/testimonials/1656505269testimonial-1.png" alt="Chandrakant Patil"></figure>
                            <div class="info-box">
                                <h5>Chandrakant Patil</h5>
                                <span class="designation">Builder</span>
                            </div>
                        </div>
						                        <div class="thumb-item">
                            <figure class="thumb-box"><img src="assets/images/defualttestimonial.jpg" alt="Abdul Rahaman"></figure>
                            <div class="info-box">
                                <h5>Abdul Rahaman</h5>
                                <span class="designation">Civil Contractor</span>
                            </div>
                        </div>
						                        <div class="thumb-item">
                            <figure class="thumb-box"><img src="assets/images/defualttestimonial.jpg" alt="Rachna Patel"></figure>
                            <div class="info-box">
                                <h5>Rachna Patel</h5>
                                <span class="designation">Architecturer</span>
                            </div>
                        </div>
						                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial-section end -->

    <!-- clients-section -->
    <section class="clients-section service-style-three" style="padding-bottom:90px;">
        <div class="auto-container">
            <div class="sec-title centred" style="margin-bottom:100px;">
                <h5>Our Events</h5>
                <h2>Recent Updates</h2>
            </div>
            <div class="clients-carousel owl-carousel owl-theme">
										<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1661835509events010.jpeg" alt=""></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1689571376WhatsApp-Image-2023-06-22-at-20.56.56.jpeg" alt="Plumber Meet"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/16629629271.jpg" alt="Ganga"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/16629629092.jpg" alt="Ganga"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/16629630073.jpg" alt="Ganga"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/16629630834.jpg" alt="Ganga"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1663064479WhatsApp-Image-2022-09-13-at-00.05.50.jpeg" alt="Ganga"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1689571412WhatsApp-Image-2023-06-22-at-20.56.57.jpeg" alt="Plumber Meet"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1689571427WhatsApp-Image-2023-07-10-at-19.44.15.jpeg" alt="Plumber Meet"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1661835363events002.jpeg" alt=""></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1689571442WhatsApp-Image-2023-07-10-at-19.44.39.jpeg" alt="Plumber Meet"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/16954732801695448588640.jpg" alt="Plumber Meet"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/16954735451693291591944.jpg" alt="Plumber Meet"></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1661835393events005.jpg" alt=""></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1661835403events006.jpeg" alt=""></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1661835467events007.jpeg" alt=""></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1661835482events008.jpeg" alt=""></a></figure>
												<figure class="client-logo"><a href="javascript:void(0)"><img src="http://gangapipes.com//upload/brandlogo/1661835497events009.jpeg" alt=""></a></figure>
						            </div>
        </div>
    </section>
    <!-- clients-section end -->


    <!-- cta-section -->
    <section class="cta-section">
        <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-3.png);"></div>
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title pull-left">
                    <h2>Request A Quote</h2>
                </div>
                <div class="btn-box pull-right">
                    <a href="inquiry.php">get in touch</a>
                </div>
            </div>
        </div>
    </section>
    <!-- cta-section end -->


    <!-- fun-fact -->
    <section class="fun-fact centred">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="2500">0</span>+
                        </div>
                        <p>Dealer Network</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="150">0</span>+
                        </div>
                        <p>Distributor Network</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="2">0</span>M+
                        </div>
                        <p>Satisfied Customers</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 counter-column">
                    <div class="counter-block-one wow slideInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="count-outer count-box">
                            <span class="count-text" data-speed="1500" data-stop="1000">0</span>+
                        </div>
                        <p>Projects Delivered</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- fun-fact end -->


    <!-- main-footer -->
    <footer class="main-footer">
        <div class="footer-top">
            <div class="auto-container">
                <div class="widget-section">
                    <div class="row clearfix">
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="#"><img src="assets/images/footer-logo.png" alt=""></a></figure>
								<p style="width:90%">Serving The World Since More Than 30 Years and Having Expertise in Manufacturing of CPVC, UPVC, & SWR Pipes & Fittings.<br /><br /></p>
                                <ul class="social-links clearfix">
															<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
																						<li><a href="https://in.linkedin.com/company/gangapipesindia" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
																						<li><a href="https://www.instagram.com/gangapipes/" target="_blank"><i class="fab fa-instagram"></i></a></li>
																						<li><a href="https://www.youtube.com/channel/UCRlxf7kGZzCaQeEGFwRvwQw/featured" target="_blank"><i class="fab fa-youtube"></i></a></li>
																						<li><a href="https://wa.me/919725534743?text=I'm%20interested%20in%20your%20Products" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
							                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
								<div class="widget-title">
                                    &nbsp;
                                </div>
                                <ul class="info-list clearfix" style="padding-top:20px;">
                                    <li><i class="fas fa-map-marker-alt"></i>Survey No. 211, Plot No. 9 & 11, Narmada Pipes Gate, National Highway - 27, Veraval (Shapar)-360024, Tal: Kotda Sangani, Dist: Rajkot, Gujarat, INDIA</li>
                                    <li><i class="fas fa-envelope"></i>Email: <a href="mailto:info@gangapipes.com">info@gangapipes.com</a></li>
                                    <li><i class="fas fa-headphones"></i>Call: <a href="tel:18003130822">1800 313 0822</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml-70">
                                <div class="widget-title">
                                    <h4>Useful Links</h4>
                                </div>
                                <div class="widget-content">
                                    <ul class="list clearfix row">
																									<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=1">CPVC Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=2">UPVC Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=3">UPVC SWR Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=4">Agri Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=5">PPR Pipes & Fittings</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=6">HDPE Pipes</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=7">Drip Irrigation System</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=8">Sprinkler Irrigation System</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=9">Casing Pipes</a></li>
																											<li class="col-lg-6 col-md-6 col-sm-12"><a href="category.php?cid=10">PE-X Pipes</a></li>
													                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="copyright"><p>&copy; 2022 <a href="#">Ganga Pipes</a>. All rights reserved.</p></div>
            </div>
        </div>
    </footer>
    <!-- main-footer end -->

    <!--Scroll to top-->
    <button class="scroll-top scroll-to-target" data-target="html">
        <span class="fa fa-arrow-up"></span>
    </button><!-- jequery plugins -->
<div style="position:fixed;z-index:4444;background: rgba(0,0,0,0.4);width: 200px;bottom:12px;right:15px;padding: 0px 10px;border-radius: 5px;color: #fff;font-size: 13px;display:none;" id="rightclick">
	Right Click Disabled.
</div>
<script src="assets/js/jquery.js?var=29"></script>
<script src="assets/js/popper.min.js?var=29"></script>
<script src="assets/js/bootstrap.min.js?var=29"></script>
<script src="assets/js/owl.js?var=29"></script>
<script src="assets/js/wow.js?var=29"></script>
<script src="assets/js/validation.js?var=29"></script>
<script src="assets/js/jquery.fancybox.js?var=29"></script>
<script src="assets/js/appear.js?var=29"></script>
<script src="assets/js/jquery.countTo.js?var=29"></script>
<script src="assets/js/scrollbar.js?var=29"></script>
<script src="assets/js/nav-tool.js?var=29"></script>
<script src="assets/js/TweenMax.min.js?var=29"></script>
<script src="assets/js/circle-progress.js?var=29"></script>
<script src="assets/js/jquery.nice-select.min.js?var=29"></script>
<!-- main-js -->
<script src="assets/js/script.js?var=29"></script>
<script type="text/javascript">
var rclickblock = $("#rightclick");
$(document).bind("contextmenu",function(e){
		rclickblock.show();
		setInterval(function() {
			rclickblock.hide();
		}, 2000);
		return false;
    });
</script></body><!-- End of .page_wrapper -->
</html>